#!/bin/sh
#> /home/gdp24/maya/projects/cag2_cloth/renderlog.txt
#Render -rd /home/gdp24/maya/projects/cag2_cloth/images -im outputim -of jpg /home/gdp24/workspaces/github/cag2/t4_cloth/scenes/shaderTest.ma
Render -rd /home/gdp24/maya/projects/cag2_cloth/images -im outputim -of jpg /home/gdp24/workspaces/github/cag2/t4_cloth/scenes/cloth4_wind.ma
#Render -rd /home/gdp24/maya/projects/cag2_cloth/images -im outputim -of jpg /home/gdp24/workspaces/github/cag2/t4_cloth/scenes/shaderTestGlobalIlum.ma
